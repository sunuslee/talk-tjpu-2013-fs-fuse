#include <stdlib.h>
#include "vivian.h"
#define FALSE 0
#define TRUE !FALSE

#define CALLOC_S(type, ptr, nelem, elem_size)   \
do                                              \
{                                               \
        ptr = (type *)calloc(nelem,elem_size);  \
}while(0)


#define DEBUG_INTERP    0x1
#define DEBUG_PASS      0x2
#define SET_DEBUG_FLAG(v, flag) (v|=flag)

/* SAMPLES:
 * * DEBUG_ARGS(1,val,"I ALSO WANT TO CHECK val2 = %d\n",val2);
 * * Or
 * * DEBUG_ARGS(1,val,"I ALSO WANT TO ADD THIS INFO");
 * */
#define DEBUG(flag, info,...)                                                   \
do                                                                              \
{                                                                               \
        if(flag)                                                                \
        {                                                                       \
                printf("Debug Info :%s , %s:%d\n",                              \
                        __FILE__,__func__,__LINE__);                            \
                printf(info"\n", ##__VA_ARGS__);                                \
                /* ##__VA_ARGS__ is supported by GCC ONLY!*/                    \
                if (flag & DEBUG_INTERP)                                        \
                        while(getchar() != 'c')                                 \
                /* Press 'C' to continue */ ;                                   \
        }                                                                       \
} while(0)


char *abs_path(vivian_t *v, const char *path, char *abs_path);

int v_error(vivian_t *v, const char *path, char *str);
