#include "vivian.h"

#include <fuse.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>

FILE * get_logger()
{
    FILE * logger;
    logger = fopen("vivian.log", "w");
    if (logger == NULL) {
            return NULL;
    }
    setvbuf(logger, NULL, _IOLBF, 0);
    return logger;
}

int is_exclude(const char *path)
{
        const char *exclude_list[] = {
                "/.git/",
                "/.gitignore",
        };
        int i;
        for  (i = 0; i < sizeof(exclude_list)/sizeof(char *); i++) {
                if (strstr(path, exclude_list[i]))
                        return 1;
        }
        return 0;
}

void _log_msg(const char *file, const char *function, int line,
              FILE * logger, const char *path, const char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    if (is_exclude(path))
            return ;
    fprintf(logger, "Debug [%s : %s : %d]\n",
                        file, function, line);
    fprintf(logger, "PATH: %s\t", path);
    vfprintf(logger, format, ap);
    fprintf(logger, "\n\n");
}
