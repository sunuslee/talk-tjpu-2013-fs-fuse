#ifndef _VIVIAN_H_
#define _VIVIAN_H_
#include <limits.h>
#include <stdio.h>
/* FORCE FUSE VERSON */
#define FUSE_USE_VERSION 26
#define _XOPEN_SOURCE 500
#define MAX_PATH_LEN 256
#define MAGIC "vivian&sunus"
#include <fuse.h>
#include <stdio.h>
struct _vivian {
        char rootdir[MAX_PATH_LEN];
        char *magic;
        char syncdir[MAX_PATH_LEN];
        FILE *logger;
};


typedef struct _vivian vivian_t;

#define V_DATA ((vivian_t *) fuse_get_context()->private_data)
#endif
