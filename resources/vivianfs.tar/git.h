int git_init(const char *repo, const char *user, const char *email);
int git_commit(const char *repo, const char *comment);
