#include <stdio.h>
#include <stdlib.h>

int git_init(const char *repo, const char *user, const char *email)
{
        char cmd[256];
        sprintf(cmd, "./git_init.sh %s \"%s\" %s", repo, user, email);
        printf("git init run cmd:\n%s", cmd);
        return system(cmd);
}

int git_commit(const char *repo, const char *comment)
{
        char cmd[256];
        sprintf(cmd, "./git_commit.sh %s \"%s\"", repo, comment);
        printf("git commit run cmd:\n%s", cmd);
        return system(cmd);
}
