#include "vivian.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "common.h"
#include "logger.h"

char * abs_path(vivian_t *v, const char *path, char *abs_path)
{
        strcpy(abs_path, v->rootdir);
        strncat(abs_path, path, PATH_MAX);
        return abs_path;
}

int v_error(vivian_t *v, const char *path, char *str)
{
        int ret = -errno;
        DEBUG(DEBUG_PASS, "ERROR %s: %s\n", str, strerror(errno));
        log_msg(v->logger, path, "ERROR %s: %s\n", str, strerror(errno));
        return ret;
}
