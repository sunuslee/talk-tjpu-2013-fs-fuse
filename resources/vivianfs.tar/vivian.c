#include "vivian.h"

#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <fuse.h>
#include <unistd.h>

#include "logger.h"
#include "operations.h"
#include "common.h"
#include "git.h"

int main(int argc, char *argv[])
{
	vivian_t vivian;
        struct fuse_operations v_opers = {
                .init = v_init,
                .getattr = v_getattr,
                .fgetattr = v_fgetattr,
                .fsync = v_fsync,
                .access = v_access,
                .create = v_create,
                .mknod = v_mknod,
                .flush = v_flush,
                .setxattr = v_setxattr,
                .getxattr = v_getxattr,
                .utime = v_utime,
                .chown = v_chown,
                .chmod = v_chmod,
                .open = v_open,
                .read = v_read,
                .write = v_write,
                .release = v_release,
                .unlink = v_unlink,
                .opendir = v_opendir,
                .readdir = v_readdir,
                .releasedir = v_releasedir,
                .mkdir = v_mkdir,
        };
        vivian.logger = get_logger();
        if (!vivian.logger) {
                DEBUG(DEBUG_INTERP, "Logger open failed!");
                return -1;
        }
        if (realpath(argv[1], vivian.rootdir)) {
                DEBUG(DEBUG_PASS, "Mounting path: %s", vivian.rootdir);
                log_msg(vivian.logger, vivian.rootdir, "Mounting");
        }
        argv[1] = argv[0];
        fuse_main(argc - 1, argv + 1, &v_opers, &vivian);
        return 0;
}
