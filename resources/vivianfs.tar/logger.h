#ifndef _LOGGER_H_
#define _LOGGER_H_
#include <stdio.h>


//  macro to log fields in structs.
#define log_struct(st, field, format, typecast) \
  log_msg("    " #field " = " #format "\n", typecast st->field)
FILE * get_logger(void);

#define log_msg(logger, path, ...) _log_msg(__FILE__, __func__, __LINE__, \
                                            logger, path, ##__VA_ARGS__ )

void _log_msg(const char *file, const char *function, int line,
              FILE * logger, const char *path, const char *format, ...);
#endif
