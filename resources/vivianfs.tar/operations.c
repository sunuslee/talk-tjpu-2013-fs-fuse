#include "vivian.h"
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <fuse.h>
#include "common.h"
#include "operations.h"
#include "logger.h"
#include "git.h"

/*
 * Contains the basic file operation of vivianFS
 */

void *v_init(struct fuse_conn_info *conn)
{
        vivian_t *v;
        char git_repo_path[MAX_PATH_LEN];
        v = V_DATA;
        strcat(strcpy(git_repo_path, v->rootdir), ".git");
        if (!opendir(git_repo_path)) {
                git_init(v->rootdir, "0x73756e7573", "sunuslee@gmail.com");
                log_msg(v->logger, v->rootdir, "git init repo");
        }
        else {
                log_msg(v->logger, v->rootdir, "git repo found: %s", git_repo_path);
        }
        log_msg(v->logger, v->rootdir, "init finished", v);
        return v;
}

int v_getattr(const char *path, struct stat *statbuf)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        abs_path(v, path, abspath);
	DEBUG(DEBUG_PASS, "path = %s abs_path = %s", path, abspath);
        DEBUG(DEBUG_PASS, "statbuf = %p", statbuf);
        retstat = lstat(abspath, statbuf);
        DEBUG(DEBUG_PASS, "retstat = %d", retstat);
        if (retstat != 0)
                retstat = v_error(v, path, "getattr lstat");
        return retstat;
}


int v_open(const char *path, struct fuse_file_info *fi)
{
        int retstat = 0;
        int fd;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "fi: %p", fi);
        abs_path(v, path, abspath);
        fd = open(abspath, fi->flags);
        if (fd < 0)
                retstat = v_error(v, path, "open error");
        fi->fh = fd;
        DEBUG(DEBUG_PASS, "open %s, fd = %d", path, fd);
        return retstat;
}

int v_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
        int retval;
        vivian_t *v;
        v = V_DATA;
        DEBUG(DEBUG_PASS, "enter read path: %s fi %p buf %p\nsize: %zd offset %zd",
              path, fi, buf, size, offset);
        retval = pread(fi->fh, buf, size, offset);
        if (retval < 0)
                retval = v_error(v, path, "v_read error");
        return retval;
}

int v_write(const char *path, const char *buf, size_t size,
                off_t offset, struct fuse_file_info *fi)
{
        int retstat = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "buf=0x%08x, size=%d, offset=%lld"
                "fi=0x%08x data:\n%.64s",
                buf, size, offset, fi, buf);
        retstat = pwrite(fi->fh, buf, size, offset);
        if (retstat < 0)
                retstat = v_error(v, path, "write pwrite error");
        return retstat;
}

int v_readlink(const char *path, char *link, size_t size)
{
        DEBUG(DEBUG_PASS, "enter readlink path: %s link %p size %zd",
              path, link, size);
        return 0;
}

int v_access(const char *path, int mask)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        abs_path(v, path, abspath);
        DEBUG(DEBUG_PASS, "access path: %s abspath:%s mask:%d v: %p",
              path, abspath, mask, v);
        log_msg(v->logger, path, "mask=0%o", mask);
        retstat = access(abspath, mask);
        if (retstat < 0)
                retstat = v_error(v, path, "v_access error");
        return retstat;
}

int v_create(const char *path, mode_t mode, struct fuse_file_info *fi)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        int fd;
        char comment[256];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "mode=0%03o, fi=%p",
                mode, fi);
        abs_path(v, path, abspath);
        fd = creat(abspath, mode|S_IRWXU|S_IRWXG|S_IRWXO);
        if (fd < 0)
                retstat = v_error(v, path, "v_create error");
        else {
                sprintf(comment, "create a new file %s", path);
                git_commit(v->rootdir, comment);
        }
        fi->fh = fd;
        return retstat;
}

int v_mknod(const char *path, mode_t mode, dev_t dev)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "mode=0%3o, dev=%lld",
                mode, dev);
        abs_path(v, path, abspath);

        if (S_ISREG(mode)) {
                retstat = open(abspath, O_CREAT | O_EXCL | O_RDWR, mode);
                if (retstat < 0)
                        retstat = v_error(v, path, "v_mknod open");
                else {
                        retstat = close(retstat);
                        if (retstat < 0)
                                retstat = v_error(v, path, "v_mknod close");
                }
        } else if (S_ISFIFO(mode)) {
                retstat = mkfifo(abspath, mode);
                if (retstat < 0)
                        retstat = v_error(v, path, "v_mknod mkfifo");
        } else {
                retstat = mknod(abspath, mode, dev);
                if (retstat < 0)
                        retstat = v_error(v, path, "v_mknod mknod");
        }
        return retstat;
}

int v_flush(const char *path, struct fuse_file_info *fi)
{
        vivian_t *v;
        v = V_DATA;
        // Always successed.
        log_msg(v->logger, path, "flush finished. path: %s fi: %p", fi);
        DEBUG(DEBUG_PASS, "flush finished. path:%s fi: %p", path, fi);
        return 0;
}

int v_setxattr(const char *path, const char *name, const char *value, size_t size, int flags)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "name=\"%s\", value=\"%s\", size=%d, flags=0x%08x)",
                name, value, size, flags);
        abs_path(v, path, abspath);
        retstat = lsetxattr(abspath, name, value, size, flags);
        if (retstat < 0)
                retstat = v_error(v, path, "setxattr error! ");
        return retstat;
}

int v_utime(const char *path, struct utimbuf *ubuf)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "ubuf=0x%08x",
                ubuf);
        abs_path(v, path, abspath);
        retstat = utime(abspath, ubuf);
        if (retstat < 0)
                retstat = v_error(v, path, "v_utime error");
        DEBUG(DEBUG_PASS, "flush finished. path:%s ubut: %p", path, ubuf);
        return retstat;
}

int v_chown(const char *path, uid_t uid, gid_t gid)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "uid=%d, gid=%d",
                uid, gid);
        abs_path(v, path, abspath);
        retstat = chown(abspath, uid, gid);
        DEBUG(DEBUG_PASS, "path: %s uid %d gid %d", path, uid, gid);
        if (retstat < 0)
                retstat = v_error(v, path, "v_chown error");
        return retstat;
}

int v_chmod(const char *path, mode_t mode)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "mode=0%03o", mode);
        abs_path(v, path, abspath);
        retstat = chmod(abspath, mode);
        if (retstat < 0)
                retstat = v_error(v, path, "v_chmod chmod");
        return retstat;
}

int v_release(const char *path, struct fuse_file_info *fi)
{
        int retstat = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "fi=0x%08x", fi);
        // We need to close the file.  Had we allocated any resources
        // (buffers etc) we'd need to free them here as well.
        retstat = close(fi->fh);
        DEBUG(DEBUG_PASS, "path = %s fi = %p", path, fi);
        return retstat;
}

int v_fgetattr(const char *path, struct stat *statbuf, struct fuse_file_info *fi)
{
        int retstat = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "statbuf=0x%08x, fi=0x%08x",
                statbuf, fi);
        retstat = fstat(fi->fh, statbuf);
        if (retstat < 0)
                retstat = v_error(v, path, "v_fgetattr fstat");
        return retstat;
}

int v_fsync(const char *path, int datasync, struct fuse_file_info *fi)
{
        int retstat = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "datasync=%d, fi=0x%08x",
                datasync, fi);
        if (datasync)
                retstat = fdatasync(fi->fh);
        else
                retstat = fsync(fi->fh);
        if (retstat < 0)
                v_error(v, path, "v_fsync fsync");
        return retstat;
}

int v_getxattr(const char *path, const char *name, char *value, size_t size)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "name = \"%s\", value = 0x%08x, size = %d",
                name, value, size);
        abs_path(v, path, abspath);
        retstat = lgetxattr(abspath, name, value, size);
        if (retstat < 0)
                retstat = v_error(v, path, "v_getxattr lgetxattr");
        else
                log_msg(v->logger, path, "value = \"%s\"", value);
        return retstat;
}

int v_unlink(const char *path)
{
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "");
        abs_path(v, path, abspath);
        retstat = unlink(abspath);
        if (retstat < 0)
                retstat = v_error(v, path, "unlink");
        return retstat;
}

int v_opendir(const char *path, struct fuse_file_info *fi)
{
        DIR *dp;
        int retstat = 0;
        char abspath[MAX_PATH_LEN];
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "fi=0x%08x", fi);
        abs_path(v, path, abspath);
        dp = opendir(abspath);
        if (dp == NULL)
                retstat = v_error(v, path, "v_opendir opendir");
        fi->fh = (intptr_t) dp;
        DEBUG(DEBUG_PASS, "opendir %s", path);
        return retstat;
}

int v_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset,
              struct fuse_file_info *fi)
{
        int ret = 0;
        DIR *dp;
        struct dirent *de;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "buf=0x%08x, filler=0x%08x, offset=%lld, fi=0x%08x",
                buf, filler, offset, fi);
        dp = (DIR *) (uintptr_t) fi->fh;
        de = readdir(dp);
        if (de == 0) {
                ret = v_error(v, path, "v_readdir readdir");
                return ret;
        }
        do {
                log_msg(v->logger, path, "calling filler with name %s", de->d_name);
                if (filler(buf, de->d_name, NULL, 0) != 0) {
                        log_msg(v->logger, path, "ERROR v_readdir filler:  buffer full");
                        return -ENOMEM;
                }
        } while ((de = readdir(dp)) != NULL);
        DEBUG(DEBUG_PASS, "readdir %s", path);
        return ret;
}

int v_releasedir(const char *path, struct fuse_file_info *fi)
{
        int ret = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "fi=0x%08x", fi);
        closedir((DIR *) (uintptr_t) fi->fh);
        DEBUG(DEBUG_PASS, "release dir %s", path);
        return ret;
}

int v_fsyncdir(const char *path, int datasync, struct fuse_file_info *fi)
{
        int ret = 0;
        vivian_t *v;
        v = V_DATA;
        log_msg(v->logger, path, "datasync=%d, fi=0x%08x",
                datasync, fi);
        return ret;
}

int v_mkdir(const char *path, mode_t mode)
{
        int ret;
        vivian_t *v;
        v = V_DATA;
        char abspath[MAX_PATH_LEN];
        char comment[256];
        abs_path(v, path, abspath);
        ret = mkdir(abspath, mode|S_IFDIR);
        if (ret != 0) 
                v_error(v, path, "mkdir error");
        else {
                sprintf(comment, "create a new dir %s", path);
                git_commit(v->rootdir, comment);
        }
        DEBUG(DEBUG_PASS, "mkdir: %s", path);
        return ret;
}
