#!/bin/bash

# Init a git repo at path $1 
# with username $2 and email $3

cd $1
git init 1>/dev/null
echo [User] >> .git/config
echo name = $2 >> .git/config
echo email = $3 >> .git/config
echo `date` > .sunus
echo '*.swp' >> .gitignore
echo '*.swp*' >> .gitignore
echo '*~' >> .gitignore
git add . 1>/dev/null
git commit -am "start at `date`" 1>/dev/null

