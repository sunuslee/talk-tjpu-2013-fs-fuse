#!/bin/bash

# do a commit at repo $1
# with comment $2.

cd $1
git add .
git commit -m "$2"
