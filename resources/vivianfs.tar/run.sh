#!/bin/bash
./vivian $1 $2 -d -s
sleep 3600
