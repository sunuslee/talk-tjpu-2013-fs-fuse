#!/usr/bin/env python
# encoding=utf-8


import argparse


def main():
    parser = argparse.ArgumentParser(description='Test basic file operations')
    parser.add_argument("file", help="Filename for the opeartion")
    parser.add_argument("-o", "--operation", help="File Operation [r/w/a]")
    parser.add_argument("-d", "--data", help="datas to write", default="")
    args = parser.parse_args()
    
    operation = 'r'
    if args.operation:
        operation = args.operation

    with open(args.file, operation) as f:
        if operation == 'w' or operation == 'a':
            f.write(args.data)
            print 'wrote finished'
        else:
            print 'read:', f.read()


if __name__ == '__main__':
    main()
